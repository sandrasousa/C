﻿namespace Modelos_Fabricados
{
    partial class FormInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormInicial));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonSair = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMudarU = new System.Windows.Forms.ToolStripButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonPriver = new System.Windows.Forms.Button();
            this.buttonOutinv = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStripButtonAlterarUser = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonSair,
            this.toolStripButtonMudarU,
            this.toolStripButtonAlterarUser});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1106, 37);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButtonSair
            // 
            this.toolStripButtonSair.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButtonSair.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonSair.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonSair.Image")));
            this.toolStripButtonSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSair.Name = "toolStripButtonSair";
            this.toolStripButtonSair.Size = new System.Drawing.Size(34, 34);
            this.toolStripButtonSair.Text = "Sair";
            this.toolStripButtonSair.Click += new System.EventHandler(this.toolStripButtonSair_Click);
            // 
            // toolStripButtonMudarU
            // 
            this.toolStripButtonMudarU.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButtonMudarU.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonMudarU.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMudarU.Image")));
            this.toolStripButtonMudarU.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMudarU.Name = "toolStripButtonMudarU";
            this.toolStripButtonMudarU.Size = new System.Drawing.Size(34, 34);
            this.toolStripButtonMudarU.Text = "Mudar Utilizador";
            this.toolStripButtonMudarU.Click += new System.EventHandler(this.toolStripButtonMudarU_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(853, 40);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 624);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // buttonPriver
            // 
            this.buttonPriver.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPriver.Location = new System.Drawing.Point(481, 417);
            this.buttonPriver.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.buttonPriver.Name = "buttonPriver";
            this.buttonPriver.Size = new System.Drawing.Size(124, 60);
            this.buttonPriver.TabIndex = 2;
            this.buttonPriver.Text = "Coleção Primavera/Verão";
            this.buttonPriver.UseVisualStyleBackColor = true;
            this.buttonPriver.Click += new System.EventHandler(this.buttonPriver_Click);
            // 
            // buttonOutinv
            // 
            this.buttonOutinv.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOutinv.Location = new System.Drawing.Point(676, 417);
            this.buttonOutinv.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.buttonOutinv.Name = "buttonOutinv";
            this.buttonOutinv.Size = new System.Drawing.Size(120, 60);
            this.buttonOutinv.TabIndex = 3;
            this.buttonOutinv.Text = "Coleção Outono/Inverno";
            this.buttonOutinv.UseVisualStyleBackColor = true;
            this.buttonOutinv.Click += new System.EventHandler(this.buttonOutinv_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.SlateGray;
            this.label1.Location = new System.Drawing.Point(532, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 50);
            this.label1.TabIndex = 4;
            this.label1.Text = "Women Brand for Women\r\n2015/2016";
            // 
            // toolStripButtonAlterarUser
            // 
            this.toolStripButtonAlterarUser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonAlterarUser.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAlterarUser.Image")));
            this.toolStripButtonAlterarUser.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAlterarUser.Name = "toolStripButtonAlterarUser";
            this.toolStripButtonAlterarUser.Size = new System.Drawing.Size(34, 34);
            this.toolStripButtonAlterarUser.Text = "Alterar Utilizadores";
            this.toolStripButtonAlterarUser.Click += new System.EventHandler(this.toolStripButtonAlterarUser_Click);
            // 
            // FormInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(5F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1106, 663);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonOutinv);
            this.Controls.Add(this.buttonPriver);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.toolStrip1);
            this.Font = new System.Drawing.Font("Arial Narrow", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "FormInicial";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormInicial_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButtonSair;
        private System.Windows.Forms.ToolStripButton toolStripButtonMudarU;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonPriver;
        private System.Windows.Forms.Button buttonOutinv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripButton toolStripButtonAlterarUser;
    }
}

