﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modelos_Fabricados
{
    public partial class FormInicial : Form
    {
        public FormInicial()
        {
            InitializeComponent();
        }

        private void toolStripButtonSair_Click(object sender, EventArgs e)
        {
            //Fecha a aplicação
            Application.Exit();
        }

        private void toolStripButtonMudarU_Click(object sender, EventArgs e)
        {
            //Abre o Form de Login 
            FormLogin login = new FormLogin();

            login.ShowDialog();
        }

        private void FormInicial_Load(object sender, EventArgs e)
        {
            //Inicia a aplicação com o Form de Login
            FormLogin login = new FormLogin();

            login.ShowDialog();
        }

        private void buttonOutinv_Click(object sender, EventArgs e)
        {
            //Abre o Form de Ver os modelos da Coleção Outono/Inverno
            FormOutinv outinv = new FormOutinv();

            outinv.ShowDialog();
        }

        private void buttonPriver_Click(object sender, EventArgs e)
        {
            //Abre o Form de Ver os modelos da Coleção Primavera/Verão
            FormPrimVer primver = new FormPrimVer();

            primver.ShowDialog();
        }

        private void toolStripButtonAlterarUser_Click(object sender, EventArgs e)
        {
            //Abre o Form que permite alterar os utilizadores da aplicação
            FormAlterarUser user = new FormAlterarUser();

            user.ShowDialog();
        }
    }
}
