﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//SQL Server
using System.Configuration;
using System.Data.SqlClient;

namespace Modelos_Fabricados
{
    public partial class FormLogin : Form
    {
        //SQL
        public static string conection = ConfigurationManager.ConnectionStrings["DbModelosFabricadosConnectionStringSQLServer"].ConnectionString;

        public FormLogin()
        {
            InitializeComponent();
        }

        private void buttonSair_Click(object sender, EventArgs e)
        {
            //Fechar a aplicação
            Application.Exit();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            //Efetuar login utilizando os dados da Tabela de Utizadores na base de dados

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand("SELECT Estado FROM TbUtilizadores WHERE Nome Like '" + textBoxUtilizador.Text + "' AND Senha Like '" + textBoxSenha.Text + "'", conexao);

            try
            {
                conexao.Open();
                var value = cmd.ExecuteScalar();

                if (value != null)
                {
                    if (value.ToString() == "ativo")
                    {
                        this.Close();
                        conexao.Close();
                    }
                    else
                    {
                        MessageBox.Show("Utilizador Inativo", "Erro");
                    }
                }
                else
                {
                    MessageBox.Show("Utilizador ou Senha incorretos", "Erro");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :", ex.Message);
            }
        }
    }
}
