﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//SQL Server
using System.Configuration;
using System.Data.SqlClient;

namespace Modelos_Fabricados
{
    public partial class FormOutinv : Form
    {
        //SQL
        public static string conection = ConfigurationManager.ConnectionStrings["DbModelosFabricadosConnectionStringSQLServer"].ConnectionString;

        public FormOutinv()
        {
            InitializeComponent();
        }

        private void toolStripButtonSair_Click(object sender, EventArgs e)
        {
            //Fechar o Form
            this.Close();
        }

        private void buttonVer_Click(object sender, EventArgs e)
        {
            //Ver a tabela do modelos fabricados que se encontra na base de dados 
            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand("SELECT * FROM TbOutInv", conexao);

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                DataSet ds = new DataSet();

                da.SelectCommand = cmd;
                da.Fill(ds);

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = ds.Tables[0].TableName;

                conexao.Close();

                da.Dispose();
                ds.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :", ex.Message);
            }
        }

        private void toolStripButtonAlterar_Click(object sender, EventArgs e)
        {
            //Abrir form para alterar, acrescentar ou eliminar dados
            FormAlterarOutInv alterar = new FormAlterarOutInv();

            alterar.ShowDialog();
        }

        private void FormOutinv_Load(object sender, EventArgs e)
        {
            ////////////////////////////////////////////////////
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ///////////////////////////////////////////////////////////////////////////////////
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Apresentar a imagem na pictureBox
            pictureBox2.ImageLocation = dataGridView1.CurrentRow.Cells[7].Value.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ////////////////////////////////////////////////////////
        }

        private void label7_Click(object sender, EventArgs e)
        {
            /////////////////////////////////////////////////
        }
    }
}
