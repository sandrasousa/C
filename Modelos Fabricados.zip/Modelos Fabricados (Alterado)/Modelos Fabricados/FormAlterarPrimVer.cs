﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//
using System.IO;


//Sql Server
using System.Configuration;
using System.Data.SqlClient;

namespace Modelos_Fabricados
{
    public partial class FormAlterarPrimVer : Form
    {
        //SQL
        public static string conection = ConfigurationManager.ConnectionStrings["DbModelosFabricadosConnectionStringSQLServer"].ConnectionString;

        public FormAlterarPrimVer()
        {
            InitializeComponent();
        }

        private void FormAlterarPrimVer_Load(object sender, EventArgs e)
        {
            //////////////////////////////////////////////
        }

        private void buttonVer_Click(object sender, EventArgs e)
        {
            //Ver a tabela do modelos fabricados que se encontra na base de dados 

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand("SELECT * FROM TbPrimVer", conexao);

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                DataSet ds = new DataSet();

                da.SelectCommand = cmd;
                da.Fill(ds);

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = ds.Tables[0].TableName;

                conexao.Close();

                //Limpar a memória ram
                da.Dispose();
                ds.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :", ex.Message);
            }
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            /////////////////////////////////////////////////////////////////////////////////
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Aparecer no Data Grid a base de dados
            textBoxID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBoxNome.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBoxCategoria.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBoxPreco.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            dateTimePickerData.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[4].Value);
            textBoxQuant.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            textBoxCor.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            textBoxFoto.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            pictureBox2.ImageLocation = dataGridView1.CurrentRow.Cells[7].Value.ToString();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //Confirmar se quer sair do Form
            if (!(MessageBox.Show("Tem a certeza que quer sair ?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes))
                return;

            this.Close();
        }

        private void toolStripButtonGuardar_Click(object sender, EventArgs e)
        {
            //Inserir um modelo à base de dados 
            SqlParameter[] arParms = new SqlParameter[8];
            string sql;

            sql = "Insert Into TbPrimVer (ID, Nome, Categoria, Preco, DF, Quantidade, Cores, Fotografia) Values (@ID, @Nome, @Categoria , @Preco, @DF, @Quantidade, @Cores, @Fotografia)";

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand(sql, conexao);


            arParms[0] = new SqlParameter("@ID", Convert.ToInt32(textBoxID.Text));
            arParms[1] = new SqlParameter("@Nome", textBoxNome.Text);
            arParms[2] = new SqlParameter("@Categoria", textBoxCategoria.Text);
            arParms[3] = new SqlParameter("@Preco", Convert.ToInt32(textBoxPreco.Text));
            arParms[4] = new SqlParameter("@DF", dateTimePickerData.Value);
            arParms[5] = new SqlParameter("@Quantidade", Convert.ToInt32(textBoxQuant.Text));
            arParms[6] = new SqlParameter("@Cores", textBoxCor.Text);
            arParms[7] = new SqlParameter("@Fotografia", textBoxFoto.Text);

            foreach (SqlParameter p in arParms)
            {
                cmd.Parameters.Add(p);
            }
            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                //Limpar conteúdos 
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxCategoria.Text = "";
                textBoxPreco.Text = "";
                dateTimePickerData.Value = DateTime.Now;
                textBoxQuant.Text = "";
                textBoxCor.Text = "";
                textBoxFoto.Text = "";
                pictureBox2.ImageLocation = "";

                MessageBox.Show("Gravado Com Sucesso");

                //Ver tabela após estar inserido sem ser necessario clicar no botão "Ver Modelos"
                buttonVer_Click(sender, e);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

        private void toolStripButtonEliminar_Click(object sender, EventArgs e)
        {
            //Confirmar se quer apagar o modelo selecionado 
            if (!(MessageBox.Show("Tem a certeza que pretende eliminar este modelo ?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes))
                return;

            //Eliminar modelos
            SqlParameter[] arParms = new SqlParameter[1];
            string sql;

            sql = "Delete From TbPrimVer Where ID=@ID";

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand(sql, conexao);


            arParms[0] = new SqlParameter("@ID", Convert.ToInt32(textBoxID.Text));

            foreach (SqlParameter p in arParms)
            {
                cmd.Parameters.Add(p);
            }

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                //Limpar conteúdos
                textBoxID.Text = "";
                pictureBox2.ImageLocation = "";

                MessageBox.Show("Eliminado Com Sucesso");
                //Ver tabela após eliminar sem ser necessario clicar no botão "Ver Modelos"
                buttonVer_Click(sender, e);
                //Apagar os dados da textBox após ser inserido
                buttonApagar_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

        private void buttonApagar_Click(object sender, EventArgs e)
        {
            //Apagar/Inserir dados do modelo nas textBox
            try
            {
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxCategoria.Text = "";
                textBoxPreco.Text = "";
                dateTimePickerData.Value = DateTime.Now;
                textBoxQuant.Text = "";
                textBoxCor.Text = "";
                textBoxFoto.Text = "";
                pictureBox2.ImageLocation = "";
            }
            catch
            {

            }
        }

        private void buttonAtualizar_Click(object sender, EventArgs e)
        {
            //Atualizar os modelos já existentes
            SqlParameter[] arParms = new SqlParameter[8];
            string sql;

            sql = "Update TbPrimVer set Nome=@Nome, Categoria=@Categoria , Preco=@Preco, DF=@DF, Quantidade=@Quantidade, Cores=@Cores, Fotografia=@Fotografia Where ID=@ID";

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand(sql, conexao);


            arParms[0] = new SqlParameter("@ID", Convert.ToInt32(textBoxID.Text));
            arParms[1] = new SqlParameter("@Nome", textBoxNome.Text);
            arParms[2] = new SqlParameter("@Categoria", textBoxCategoria.Text);
            arParms[3] = new SqlParameter("@Preco", Convert.ToInt32(textBoxPreco.Text));
            arParms[4] = new SqlParameter("@DF", dateTimePickerData.Value);
            arParms[5] = new SqlParameter("@Quantidade", Convert.ToInt32(textBoxQuant.Text));
            arParms[6] = new SqlParameter("@Cores", textBoxCor.Text);
            arParms[7] = new SqlParameter("@Fotografia", textBoxFoto.Text);

            foreach (SqlParameter p in arParms)
            {
                cmd.Parameters.Add(p);
            }

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                //Limpar conteúdos
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxCategoria.Text = "";
                textBoxPreco.Text = "";
                dateTimePickerData.Value = DateTime.Now;
                textBoxQuant.Text = "";
                textBoxCor.Text = "";
                textBoxFoto.Text = "";
                pictureBox2.ImageLocation = "";

                MessageBox.Show("Atualizado com sucesso");
                //Ver tabela após atualizar sem ser necessario clicar no botão "Ver Modelos"
                buttonVer_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Procurar a imagem relativa ao modelo e mostra-la na pictureBox
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)

                {

                    textBoxFoto.Text = openFileDialog1.FileName;
                    pictureBox2.ImageLocation = openFileDialog1.FileName;
                }
                else
                {
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }

        }

        private void toolStripButtonAltualizar_Click(object sender, EventArgs e)
        {
            //Atualizar os modelos já existentes
            SqlParameter[] arParms = new SqlParameter[8];
            string sql;

            sql = "Update TbOutInv set Nome=@Nome, Categoria=@Categoria , Preco=@Preco, DF=@DF, Quantidade=@Quantidade, Cores=@Cores, Fotografia=@Fotografia Where ID=@ID";

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand(sql, conexao);


            arParms[0] = new SqlParameter("@ID", Convert.ToInt32(textBoxID.Text));
            arParms[1] = new SqlParameter("@Nome", textBoxNome.Text);
            arParms[2] = new SqlParameter("@Categoria", textBoxCategoria.Text);
            arParms[3] = new SqlParameter("@Preco", Convert.ToInt32(textBoxPreco.Text));
            arParms[4] = new SqlParameter("@DF", dateTimePickerData.Value);
            arParms[5] = new SqlParameter("@Quantidade", Convert.ToInt32(textBoxQuant.Text));
            arParms[6] = new SqlParameter("@Cores", textBoxCor.Text);
            arParms[7] = new SqlParameter("@Fotografia", textBoxFoto.Text);
            arParms[7] = new SqlParameter("@Fotografia", pictureBox2.ImageLocation);

            foreach (SqlParameter p in arParms)
            {
                cmd.Parameters.Add(p);
            }

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                //Limpar conteúdos
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxCategoria.Text = "";
                textBoxPreco.Text = "";
                dateTimePickerData.Value = DateTime.Now;
                textBoxQuant.Text = "";
                textBoxCor.Text = "";
                textBoxFoto.Text = "";
                pictureBox2.ImageLocation = "";

                MessageBox.Show("Atualizado com sucesso");
                //Ver tabela após atualizar sem ser necessario clicar no botão "Ver Modelos"
                buttonVer_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

        private void toolStripButtonNovo_Click(object sender, EventArgs e)
        {
            //Apagar/Inserir dados do modelo nas textBox
            try
            {
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxCategoria.Text = "";
                textBoxPreco.Text = "";
                dateTimePickerData.Value = DateTime.Now;
                textBoxQuant.Text = "";
                textBoxCor.Text = "";
                textBoxFoto.Text = "";
                pictureBox2.ImageLocation = "";
            }
            catch
            {

            }
        }
    }
}
