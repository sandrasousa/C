﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Sql Server
using System.Configuration;
using System.Data.SqlClient;

namespace Modelos_Fabricados
{
    public partial class FormAlterarUser : Form
    {
        //SQL
        public static string conection = ConfigurationManager.ConnectionStrings["DbModelosFabricadosConnectionStringSQLServer"].ConnectionString;

        public FormAlterarUser()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //////////////////////////////////////////////////////////////////////////////////
        }

        private void toolStripButtonGuardar_Click(object sender, EventArgs e)
        {
            //Inserir um modelo à base de dados 
            SqlParameter[] arParms = new SqlParameter[4];
            string sql;

            sql = "Insert Into TbUtilizadores (ID, Nome, Senha, Estado) Values (@ID, @Nome, @Senha , @Estado)";

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand(sql, conexao);

            arParms[0] = new SqlParameter("@ID", Convert.ToInt32(textBoxID.Text));
            arParms[1] = new SqlParameter("@Nome", textBoxNome.Text);
            arParms[2] = new SqlParameter("@Senha", textBoxSenha.Text);
            arParms[3] = new SqlParameter("@Estado", textBoxEstado.Text);

            foreach (SqlParameter p in arParms)
            {
                cmd.Parameters.Add(p);
            }
            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                //Limpar conteúdos
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxSenha.Text = "";
                textBoxEstado.Text = "";
              
                MessageBox.Show("Gravado Com Sucesso");

                //Ver tabela após estar inserido sem ser necessario clicar no botão "Ver Modelos"
                buttonVer_Click(sender, e);

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

        private void toolStripButtonEliminar_Click(object sender, EventArgs e)
        {
            //Confirmar se quer apagar o modelo selecionado 
            if (!(MessageBox.Show("Tem a certeza que quer eliminar este utilizador ?", "Eliminar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes))
                return;

            //Eliminar modelos
            SqlParameter[] arParms = new SqlParameter[1];
            string sql;

            sql = "Delete From TbUtilizadores Where ID=@ID";

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand(sql, conexao);


            arParms[0] = new SqlParameter("@ID", Convert.ToInt32(textBoxID.Text));

            foreach (SqlParameter p in arParms)
            {
                cmd.Parameters.Add(p);
            }

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                // limpa conteúdos
                textBoxID.Text = "";

                MessageBox.Show("Eliminado Com Sucesso");
                //Ver tabela após eliminar sem ser necessario clicar no botão "Ver Modelos"
                buttonVer_Click(sender, e);
                //Apagar os dados da textBox após ser inserido
                buttonApagar_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //Confirmar se quer sair do Form
            if (!(MessageBox.Show("Tem a certeza que quer sair ?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes))
                return;

            this.Close();
        }

        private void buttonAtualizar_Click(object sender, EventArgs e)
        {
            //////////////////////////////////////////////////////////////////////////
        }

        private void buttonApagar_Click(object sender, EventArgs e)
        {
            /////////////////////////////////////////////////////////////////////////
        }

        private void buttonVer_Click(object sender, EventArgs e)
        {
            //Ver a tabela do modelos fabricados que se encontra na base de dados 

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand("SELECT * FROM TbUtilizadores", conexao);

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                DataSet ds = new DataSet();

                da.SelectCommand = cmd;
                da.Fill(ds);

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = ds.Tables[0].TableName;

                conexao.Close();

                da.Dispose();
                ds.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro :", ex.Message);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Aparecer no Data Grid a base de dados
            textBoxID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBoxNome.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBoxSenha.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBoxEstado.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }

        private void toolStripButtonAltualizar_Click(object sender, EventArgs e)
        {
            //Atualizar os modelos já existentes
            SqlParameter[] arParms = new SqlParameter[4];
            string sql;

            sql = "Update TbUtilizadores set Nome=@Nome, Senha=@Senha , Estado=@Estado Where ID=@ID";

            SqlConnection conexao = new SqlConnection(conection);
            SqlCommand cmd = new SqlCommand(sql, conexao);

            arParms[0] = new SqlParameter("@ID", Convert.ToString(textBoxID.Text));
            arParms[1] = new SqlParameter("@Nome", textBoxNome.Text);
            arParms[2] = new SqlParameter("@Senha", textBoxSenha.Text);
            arParms[3] = new SqlParameter("@Estado", textBoxEstado.Text);

            foreach (SqlParameter p in arParms)
            {
                cmd.Parameters.Add(p);
            }

            try
            {
                conexao.Open();
                cmd.ExecuteNonQuery();
                //Limpar conteúdos
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxSenha.Text = "";
                textBoxEstado.Text = "";

                MessageBox.Show("Atualizado com sucesso");
                //Ver tabela após atualizar sem ser necessario clicar no botão "Ver Modelos"
                buttonVer_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro " + ex.Message);
                throw;
            }
            finally
            {
                conexao.Close();
            }
        }

        private void toolStripButtonNovo_Click(object sender, EventArgs e)
        {
            //////////////////////////////////////////////////////////////////
        }

        private void toolStripButtonNovo_Click_1(object sender, EventArgs e)
        {
            //Apagar/Inserir dados do modelo nas textBox
            try
            {
                textBoxID.Text = "";
                textBoxNome.Text = "";
                textBoxSenha.Text = "";
                textBoxEstado.Text = "";
            }
            catch
            {

            }
        }
    }
}
