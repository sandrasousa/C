﻿CREATE TABLE [dbo].[TbPrimVer] (
    [Id]         INT      NOT NULL,
    [Nome]       TEXT     NOT NULL,
    [Categoria]  TEXT     NOT NULL,
    [Preco]      INT      NOT NULL,
    [DF]         DATETIME NOT NULL,
    [Quantidade] INT      NOT NULL,
    [Cores]      TEXT     NOT NULL,
    [Fotografia] TEXT     NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

