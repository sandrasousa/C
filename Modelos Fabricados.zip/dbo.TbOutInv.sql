﻿/*
Retrieving updated definition from server
*/