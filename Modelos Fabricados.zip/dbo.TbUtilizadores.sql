﻿CREATE TABLE [dbo].[TbUtilizadores] (
    [ID]     INT  IDENTITY (1, 1) NOT NULL,
    [Nome]   TEXT NOT NULL,
    [Senha]  TEXT NOT NULL,
    [Estado] TEXT NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

